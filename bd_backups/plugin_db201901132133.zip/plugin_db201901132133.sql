--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: budget_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE budget_data (
    id integer NOT NULL,
    capture_time timestamp without time zone,
    map_id character varying(40),
    data numeric
);


ALTER TABLE budget_data OWNER TO postgres;

--
-- Name: budget_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE budget_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE budget_data_id_seq OWNER TO postgres;

--
-- Name: budget_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE budget_data_id_seq OWNED BY budget_data.id;


--
-- Name: maps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE maps (
    map_id character varying(40) NOT NULL,
    added_date timestamp without time zone
);


ALTER TABLE maps OWNER TO postgres;

--
-- Name: states_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE states_data (
    id integer NOT NULL,
    capture_time timestamp without time zone,
    map_id character varying(40),
    status_names character varying(20)[],
    status_numbers integer[],
    number integer DEFAULT 0
);


ALTER TABLE states_data OWNER TO postgres;

--
-- Name: states_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE states_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE states_data_id_seq OWNER TO postgres;

--
-- Name: states_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE states_data_id_seq OWNED BY states_data.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    user_id character varying(40) NOT NULL,
    user_name character varying(40),
    map_id character varying(40)
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: users_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users_data (
    id integer NOT NULL,
    capture_time timestamp without time zone,
    map_id character varying(40),
    role_names character varying(20)[],
    role_numbers integer[],
    number integer DEFAULT 0
);


ALTER TABLE users_data OWNER TO postgres;

--
-- Name: users_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data_id_seq OWNER TO postgres;

--
-- Name: users_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_data_id_seq OWNED BY users_data.id;


--
-- Name: budget_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY budget_data ALTER COLUMN id SET DEFAULT nextval('budget_data_id_seq'::regclass);


--
-- Name: states_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY states_data ALTER COLUMN id SET DEFAULT nextval('states_data_id_seq'::regclass);


--
-- Name: users_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users_data ALTER COLUMN id SET DEFAULT nextval('users_data_id_seq'::regclass);


--
-- Data for Name: budget_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY budget_data (id, capture_time, map_id, data) FROM stdin;
2	2019-01-09 16:31:49.855637	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110000372
3	2019-01-09 16:31:59.795052	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
4	2019-01-09 16:32:03.959774	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110000372
5	2019-01-09 16:33:41.604797	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110000372
6	2019-01-09 16:33:46.709322	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
7	2019-01-09 16:34:02.334901	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110000372
8	2019-01-09 16:34:04.326596	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
9	2019-01-09 16:34:20.398738	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
10	2019-01-09 16:34:20.972343	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
11	2019-01-09 16:34:40.378835	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
12	2019-01-09 16:34:40.995178	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
13	2019-01-09 16:35:00.395532	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
14	2019-01-09 16:35:00.928896	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
15	2019-01-09 16:35:20.406864	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
16	2019-01-09 16:35:20.841199	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
17	2019-01-09 16:35:40.40881	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
18	2019-01-09 16:35:40.963653	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
19	2019-01-09 16:36:00.450771	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
20	2019-01-09 16:36:01.164572	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
21	2019-01-09 16:36:20.629538	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
22	2019-01-09 16:36:21.281824	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
23	2019-01-09 16:36:45.58781	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
24	2019-01-09 16:36:51.440716	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
25	2019-01-09 16:37:00.497714	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
26	2019-01-09 16:37:01.125327	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
27	2019-01-09 16:37:20.520354	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
28	2019-01-09 16:37:21.302779	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
29	2019-01-09 16:37:40.460418	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002424
30	2019-01-09 16:37:41.104043	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
31	2019-01-09 16:38:00.429179	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
32	2019-01-09 16:38:00.914135	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
33	2019-01-09 16:38:20.439532	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
34	2019-01-09 16:38:20.956374	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
35	2019-01-09 16:38:40.406873	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
36	2019-01-09 16:38:40.908044	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
37	2019-01-09 16:39:00.422131	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
38	2019-01-09 16:39:01.144335	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
39	2019-01-09 23:48:59.761511	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
40	2019-01-09 23:49:00.37876	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
41	2019-01-09 23:49:19.707436	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
42	2019-01-09 23:49:20.200358	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
43	2019-01-09 23:49:48.11611	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
44	2019-01-09 23:49:48.63316	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
45	2019-01-09 23:51:18.157867	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
46	2019-01-09 23:51:18.670009	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
47	2019-01-09 23:52:36.011304	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
48	2019-01-09 23:52:36.533252	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
49	2019-01-09 23:52:56.036655	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
50	2019-01-09 23:52:56.484296	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
51	2019-01-09 23:57:46.03857	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
52	2019-01-09 23:57:46.63932	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
53	2019-01-09 23:58:03.444363	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
54	2019-01-09 23:58:03.987033	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
55	2019-01-10 00:01:26.484389	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
56	2019-01-10 00:01:27.05061	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
57	2019-01-10 00:04:41.959204	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
58	2019-01-10 00:04:42.728022	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
59	2019-01-10 00:05:01.955235	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
60	2019-01-10 00:05:02.722102	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
61	2019-01-10 00:05:23.766354	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
62	2019-01-10 00:05:24.487821	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
63	2019-01-10 00:05:42.413985	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
64	2019-01-10 00:05:43.050519	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
65	2019-01-10 00:06:03.317456	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
66	2019-01-10 00:06:04.778973	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
67	2019-01-10 00:06:21.619704	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
68	2019-01-10 00:06:22.262592	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
69	2019-01-10 00:06:41.642448	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
70	2019-01-10 00:06:42.436469	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
71	2019-01-10 00:07:23.804833	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
72	2019-01-10 00:13:02.485031	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
73	2019-01-10 00:13:03.050122	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
74	2019-01-10 00:22:32.396169	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
75	2019-01-10 00:22:33.06193	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
76	2019-01-10 00:29:46.342365	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
77	2019-01-10 00:29:46.964514	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
78	2019-01-10 00:32:17.632832	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
79	2019-01-10 00:32:18.523776	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
80	2019-01-10 00:55:44.18871	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
81	2019-01-10 00:55:44.745758	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
82	2019-01-10 00:56:04.099672	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
83	2019-01-10 00:56:04.618841	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
84	2019-01-10 00:56:24.104345	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
85	2019-01-10 00:56:24.663773	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
86	2019-01-10 00:56:44.09538	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
87	2019-01-10 00:56:44.639006	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
88	2019-01-10 01:17:42.372749	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
89	2019-01-10 20:53:06.009887	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110002523
90	2019-01-10 20:53:07.020542	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
91	2019-01-10 20:53:25.981737	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
92	2019-01-10 20:53:26.530896	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
93	2019-01-10 20:53:46.08892	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
94	2019-01-10 20:53:46.695029	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
95	2019-01-10 21:11:57.464528	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
96	2019-01-10 21:11:57.966108	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
97	2019-01-10 21:42:28.550307	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
98	2019-01-10 21:42:38.33113	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
99	2019-01-10 21:42:47.436747	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
100	2019-01-10 21:42:52.788781	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
101	2019-01-10 21:53:53.656193	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
102	2019-01-10 21:53:57.411355	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
103	2019-01-10 21:54:08.701028	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
104	2019-01-10 21:54:10.248544	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
105	2019-01-10 21:54:28.576132	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
106	2019-01-10 21:54:29.06306	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
107	2019-01-10 22:12:18.548585	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
108	2019-01-10 22:12:19.394101	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
1	2018-12-31 16:25:04.115	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	9900009
109	2019-01-11 12:18:43.691354	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
110	2019-01-11 12:20:05.480832	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
111	2019-01-11 12:22:21.189904	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
112	2019-01-11 12:23:19.661714	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
113	2019-01-11 12:24:12.907401	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
114	2019-01-11 12:24:16.464419	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
115	2019-01-11 12:41:45.941156	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
116	2019-01-11 13:31:33.928601	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
117	2019-01-11 14:15:33.419242	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
118	2019-01-11 14:16:52.040691	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
119	2019-01-11 14:18:08.380157	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
120	2019-01-11 14:22:08.345652	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
121	2019-01-11 14:25:19.970498	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
122	2019-01-11 14:25:45.657498	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
123	2019-01-11 14:27:55.540244	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
124	2019-01-11 14:29:01.114176	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
125	2019-01-11 14:29:07.239605	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
126	2019-01-11 14:29:21.028846	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
127	2019-01-11 14:29:26.600143	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
128	2019-01-11 14:29:41.207948	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
129	2019-01-11 14:32:24.380818	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
130	2019-01-11 14:32:29.970535	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
131	2019-01-11 14:32:44.30935	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
132	2019-01-11 14:33:45.677165	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
133	2019-01-11 14:33:51.5481	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
134	2019-01-11 14:34:05.668716	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
135	2019-01-11 14:34:11.371118	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
136	2019-01-11 14:34:25.673885	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
137	2019-01-11 14:34:31.681084	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
138	2019-01-11 14:39:10.959068	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
139	2019-01-11 14:42:49.964067	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
140	2019-01-11 14:43:17.534371	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
141	2019-01-11 14:43:47.681718	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
142	2019-01-11 14:43:29.726728	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
143	2019-01-11 14:43:59.213287	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
144	2019-01-11 14:43:43.951726	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
145	2019-01-11 14:44:00.254113	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
146	2019-01-11 14:44:11.523606	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
147	2019-01-11 14:44:18.165165	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
148	2019-01-11 14:44:22.720396	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
149	2019-01-11 14:44:23.723683	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
150	2019-01-11 14:44:30.482307	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
151	2019-01-11 14:50:50.459283	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
152	2019-01-11 14:50:56.169523	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
153	2019-01-11 14:59:28.341118	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
154	2019-01-11 14:59:34.451439	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
155	2019-01-11 14:59:48.371961	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
156	2019-01-11 14:59:54.010496	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
157	2019-01-11 15:00:08.415531	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	110345957
158	2019-01-11 15:00:14.850404	6d0d8ff3-e22d-4934-913d-5e04369ce150	0
\.


--
-- Data for Name: maps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY maps (map_id, added_date) FROM stdin;
16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	2019-01-09 14:22:48.3779
6d0d8ff3-e22d-4934-913d-5e04369ce150	2019-01-09 15:45:06.344102
\.


--
-- Data for Name: states_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY states_data (id, capture_time, map_id, status_names, status_numbers, number) FROM stdin;
2	2019-01-11 14:29:07.239605	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
4	2019-01-11 14:29:26.600143	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
5	2019-01-11 14:32:24.380818	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
6	2019-01-11 14:32:29.970535	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
7	2019-01-11 14:33:45.677165	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
8	2019-01-11 14:33:51.5481	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
9	2019-01-11 14:34:05.668716	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
10	2019-01-11 14:34:11.371118	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
11	2019-01-11 14:34:25.673885	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
12	2019-01-11 14:34:31.681084	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
13	2019-01-11 14:42:49.964067	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
14	2019-01-11 14:43:17.534371	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
15	2019-01-11 14:43:47.681718	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
16	2019-01-11 14:43:29.726728	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
17	2019-01-11 14:43:59.213287	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
18	2019-01-11 14:43:43.951726	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
19	2019-01-11 14:44:11.523606	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
20	2019-01-11 14:44:00.254113	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
21	2019-01-11 14:44:18.165165	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
22	2019-01-11 14:44:22.720396	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
23	2019-01-11 14:44:23.723683	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
24	2019-01-11 14:44:30.482307	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
1	2019-01-07 14:29:01.114	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
3	2019-01-10 14:29:21.028	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
25	2019-01-11 14:50:50.459283	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
26	2019-01-11 14:50:56.169523	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
27	2019-01-11 14:59:28.341118	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
28	2019-01-11 14:59:34.451439	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
29	2019-01-11 14:59:48.371961	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
30	2019-01-11 14:59:54.010496	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
31	2019-01-11 15:00:08.415531	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{development,closed}	{5,1}	6
32	2019-01-11 15:00:14.850404	6d0d8ff3-e22d-4934-913d-5e04369ce150	{}	{}	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (user_id, user_name, map_id) FROM stdin;
ef17ea4d-73da-4f7f-b8de-a8d7fb91199b	olegkosin@rambler.ru	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff
\.


--
-- Data for Name: users_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_data (id, capture_time, map_id, role_names, role_numbers, number) FROM stdin;
2	2019-01-10 12:24:16.464	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
1	2019-01-10 12:24:12.907	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
3	2019-01-11 14:15:33.419242	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
4	2019-01-11 14:16:52.040691	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
5	2019-01-11 14:18:08.380157	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
6	2019-01-11 14:22:08.345652	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
7	2019-01-11 14:25:19.970498	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
8	2019-01-11 14:25:45.657498	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
9	2019-01-11 14:27:55.540244	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
10	2019-01-11 14:29:01.114176	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
11	2019-01-11 14:29:07.239605	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
12	2019-01-11 14:29:21.028846	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
13	2019-01-11 14:29:26.600143	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
14	2019-01-11 14:32:24.380818	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
15	2019-01-11 14:32:29.970535	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
16	2019-01-11 14:33:45.677165	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
17	2019-01-11 14:33:51.5481	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
18	2019-01-11 14:34:05.668716	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
19	2019-01-11 14:34:11.371118	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
20	2019-01-11 14:34:25.673885	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
21	2019-01-11 14:34:31.681084	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
22	2019-01-11 14:42:49.964067	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
23	2019-01-11 14:43:17.534371	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
24	2019-01-11 14:43:47.681718	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
25	2019-01-11 14:43:29.726728	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
26	2019-01-11 14:43:59.213287	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
27	2019-01-11 14:43:43.951726	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
28	2019-01-11 14:44:11.523606	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
29	2019-01-11 14:44:00.254113	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
30	2019-01-11 14:44:18.165165	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
31	2019-01-11 14:44:22.720396	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
32	2019-01-11 14:44:23.723683	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
33	2019-01-11 14:44:30.482307	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
34	2019-01-11 14:50:50.459283	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
35	2019-01-11 14:50:56.169523	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
36	2019-01-11 14:59:28.341118	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
37	2019-01-11 14:59:34.451439	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
38	2019-01-11 14:59:48.371961	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
39	2019-01-11 14:59:54.010496	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
40	2019-01-11 15:00:08.415531	16d23ab1-ceb1-435b-bbb5-df1b0d72aaff	{admin}	{1}	1
41	2019-01-11 15:00:14.850404	6d0d8ff3-e22d-4934-913d-5e04369ce150	{user_rw,user_r,user_rwh,admin}	{8,1,4,2}	15
\.


--
-- Name: budget_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('budget_data_id_seq', 158, true);


--
-- Name: states_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('states_data_id_seq', 32, true);


--
-- Name: users_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_data_id_seq', 41, true);


--
-- Name: budget_data budget_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY budget_data
    ADD CONSTRAINT budget_data_pkey PRIMARY KEY (id);


--
-- Name: maps maps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY maps
    ADD CONSTRAINT maps_pkey PRIMARY KEY (map_id);


--
-- Name: states_data states_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY states_data
    ADD CONSTRAINT states_data_pkey PRIMARY KEY (id);


--
-- Name: users_data users_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users_data
    ADD CONSTRAINT users_data_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: budget_data budget_data_map_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY budget_data
    ADD CONSTRAINT budget_data_map_id_fkey FOREIGN KEY (map_id) REFERENCES maps(map_id);


--
-- Name: states_data states_data_map_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY states_data
    ADD CONSTRAINT states_data_map_id_fkey FOREIGN KEY (map_id) REFERENCES maps(map_id);


--
-- Name: users_data users_data_map_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users_data
    ADD CONSTRAINT users_data_map_id_fkey FOREIGN KEY (map_id) REFERENCES maps(map_id);


--
-- Name: users users_map_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_map_id_fkey FOREIGN KEY (map_id) REFERENCES maps(map_id);


--
-- PostgreSQL database dump complete
--

